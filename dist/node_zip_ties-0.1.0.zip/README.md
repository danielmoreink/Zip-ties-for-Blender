# Node Zip Ties 0.1.0 — experimental

Stock Blender 5.2 cannot replace individual native node links using Python. This extension therefore disables stock visual routing by default. The sidebar's experimental overlay option draws approximate paths while native links remain visible. It does not meet faithful-routing acceptance.

Hold Z and drag across at least two links, or choose Tie Wires from the node-editor Zip Ties menu. Drag a tie; Shift-drag rotates in 15° steps, Shift+Alt rotates freely. Ctrl-click toggles selection, Shift-click extends. Double-click or cut across a marker to remove it. Right-click changes color or rotates. Sidebar commands handle box selection, joint node/tie movement, copying/pasting nodes with ties, and pruning disconnected ties.

Stored JSON ID properties do not change evaluation. Disabling keeps tie data and removes handlers/keymaps. Exact routing depends on an experimental, uncompiled native Blender patch distributed in the source repository. No production parity claim is made.

Reference: https://github.com/safzanpirani/comfyui-zip-ties
See THIRD_PARTY_NOTICES.txt for the original MIT notice.
