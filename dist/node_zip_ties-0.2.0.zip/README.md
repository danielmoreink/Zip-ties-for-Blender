# Node Zip Ties 0.2.0

Works in unmodified Blender 5.2 using native reroute nodes. No patch or duplicate-noodle overlay is required. The add-on draws straps; Blender draws the wires.

Hold Z and drag across two or more wires, or choose Tie Wires from the node-editor Zip Ties context menu. Drag a tie; Shift-drag snaps rotation in 15-degree steps; Shift+Alt rotates freely. Ctrl-click toggles selection, Shift-click extends. Right-click for color, rotation and removal. Double-click or cut across a marker to remove it. The sidebar provides joint selection/movement, copy/paste, spacing and width settings.

Each tie adds three reroutes per strand. Removing the last tie restores the original direct connection. Native reroute handles can remain visible. Data and routing survive save/reload and continue to evaluate when the add-on is disabled. Earlier overlay-only ties are converted on load.

Use the provided Copy/Paste Nodes with Ties and Move Selected Nodes and Ties commands to keep straps and nodes together. Gesture picking uses approximate socket coordinates for complex custom layouts. Graphical gesture QA is pending; automated routing, evaluation, persistence, clipboard and undo tests pass in stock Blender 5.2.

Reference: https://github.com/safzanpirani/comfyui-zip-ties
See THIRD_PARTY_NOTICES.txt for the original MIT notice.
