import copy
import json
import math
import random
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, FloatVectorProperty
from . import data, geometry as g, rendering, selection, sockets, routing
from .preferences import prefs

keymaps = []


def redraw(context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'NODE_EDITOR':
                area.tag_redraw()


def point(context,event):
    region = sockets.window_region(context)
    return sockets.to_view(context,(event.mouse_x-region.x,event.mouse_y-region.y))


def hit_at(context,p):
    tree = rendering.tree_of(context)
    options = prefs(context)
    # Screen-pixel tolerance remains constant during navigation.
    a = sockets.to_view(context,(0,0))
    b = sockets.to_view(context,(6,0))
    return next((t for t in reversed(rendering.shown(tree,data.read(tree)))
                 if g.marker_hit(t,p,options.spacing,options.width,abs(b[0]-a[0]))),None)


def stroke_targets(context,ties,a,b):
    tree = rendering.tree_of(context)
    options = prefs(context)
    cuts = {t['id'] for t in rendering.shown(tree,ties) if g.marker_cut(t,a,b,options.spacing,options.width)}
    hits = []
    if not cuts:
        for link in tree.links:
            if link.is_hidden:
                continue
            key = data.link_key(link)
            hit = g.curve_hit(a,b,[sockets.controls(link,context)])
            if hit:
                hits.append((key,hit,link))
    # Several physical segments may belong to one logical wire.
    unique = {}
    for entry in hits:
        if entry[0] not in unique or entry[1][0] < unique[entry[0]][1][0]:
            unique[entry[0]] = entry
    return list(unique.values()),cuts


def new_color(context,links):
    mode = prefs(context).color_mode
    if mode == 'GREY':
        return (.55,.55,.58,1)
    if mode == 'WIRES':
        colors = [sockets.color(l,context) for l in links]
        return max(colors,key=colors.count)
    return random.choice([(.9,.28,.3,1),(.25,.4,.86,1),(.27,.65,.35,1),(.99,.77,.24,1),(.56,.3,.78,1)])


class NodeOperator:
    @classmethod
    def poll(cls,context):
        tree = rendering.tree_of(context)
        return tree is not None and tree.is_editable


class NZT_OT_hover(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_hover'
    bl_label = 'Zip Tie Hover'
    bl_options = {'INTERNAL'}

    def invoke(self,context,event):
        if rendering.usable(context):
            tie = hit_at(context,point(context,event))
            key = context.area.as_pointer()
            value = tie['id'] if tie else None
            if selection.hovered.get(key) != value:
                selection.hovered[key] = value
                redraw(context)
        return {'PASS_THROUGH'}


class NZT_OT_gesture(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_gesture'
    bl_label = 'Tie Wires'
    bl_description = 'Drag a line across at least two wires; crossing a tie cuts it'
    bl_options = {'REGISTER','UNDO','BLOCKING'}

    def invoke(self,context,event):
        if not rendering.usable(context):
            self.report({'WARNING'},'Enable Display Ties in the Zip Ties sidebar')
            return {'CANCELLED'}
        self.tree = rendering.tree_of(context)
        self.before = self.tree.get(data.KEY)
        self.node_ids = [(n,n.get(data.NODE_ID)) for n in self.tree.nodes]
        # Assign IDs before collecting keys, within this operator's undo step.
        data.repair_duplicate_ids(self.tree)
        self.ties = data.prune(self.tree,data.read(self.tree))
        self.start = point(context,event) if event.type == 'LEFTMOUSE' else None
        self.area_key = context.area.as_pointer()
        context.window_manager.modal_handler_add(self)
        context.workspace.status_text_set('Zip ties: drag across wires • Esc cancels')
        return {'RUNNING_MODAL'}

    def finish(self,context,cancel=False):
        if cancel:
            for node,original in self.node_ids:
                if original is None:
                    if data.NODE_ID in node:
                        del node[data.NODE_ID]
                else:
                    node[data.NODE_ID] = original
        selection.preview.pop(self.area_key,None)
        context.workspace.status_text_set(None)
        redraw(context)
        return {'CANCELLED'} if cancel else {'FINISHED'}

    def modal(self,context,event):
        if event.type in {'ESC','RIGHTMOUSE'} and event.value == 'PRESS':
            return self.finish(context,True)
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.start = point(context,event)
        if self.start is not None and event.type == 'MOUSEMOVE':
            p = point(context,event)
            hits,cuts = stroke_targets(context,self.ties,self.start,p)
            selection.preview[self.area_key] = (self.start,p,{h[0] for h in hits},cuts)
            redraw(context)
        if self.start is not None and event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            p = point(context,event)
            hits,cuts = stroke_targets(context,self.ties,self.start,p)
            if cuts:
                self.ties = [t for t in self.ties if t['id'] not in cuts]
                selection.of(self.tree).difference_update(cuts)
            elif len(hits) >= 2:
                tangents = [h[1][1] for h in hits]
                angle = math.atan2(sum(v[1] for v in tangents),sum(v[0] for v in tangents))
                _,normal = g.axes(angle)
                position = lambda h: g.add(self.start,g.mul(g.sub(p,self.start),h[1][0]))
                pos = [sum(position(h)[k] for h in hits)/len(hits) for k in (0,1)]
                hits.sort(key=lambda h:g.dot(position(h),normal))
                tie = data.new_tie(pos,angle,[h[0] for h in hits],self.ties,new_color(context,[h[2] for h in hits]))
                self.ties.append(tie)
                selection.of(self.tree).clear()
                selection.of(self.tree).add(tie['id'])
            else:
                return self.finish(context,True)
            data.write(self.tree,self.ties)
            return self.finish(context)
        return {'RUNNING_MODAL'}


class NZT_OT_pick(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_pick'
    bl_label = 'Select or Transform Zip Tie'
    bl_options = {'UNDO','BLOCKING'}

    def invoke(self,context,event):
        if not rendering.usable(context):
            return {'PASS_THROUGH'}
        self.tree = rendering.tree_of(context)
        self.start = point(context,event)
        hit = hit_at(context,self.start)
        if not hit:
            if not event.shift and not event.ctrl:
                selection.of(self.tree).clear()
                redraw(context)
            return {'PASS_THROUGH'}
        selected = selection.of(self.tree)
        if event.type == 'RIGHTMOUSE':
            if hit['id'] not in selected:
                selected.clear()
                selected.add(hit['id'])
            bpy.ops.wm.call_menu(name='NZT_MT_context')
            return {'FINISHED'}
        if event.value == 'DOUBLE_CLICK':
            data.write(self.tree,[t for t in data.read(self.tree) if t['id'] != hit['id']])
            selected.discard(hit['id'])
            redraw(context)
            return {'FINISHED'}
        if event.ctrl:
            selected.symmetric_difference_update({hit['id']})
            redraw(context)
            return {'FINISHED'}
        if not event.shift and hit['id'] not in selected:
            selected.clear()
        selected.add(hit['id'])
        self.original = data.read(self.tree)
        self.hit = hit
        self.rotate = event.shift
        self.offset = hit['angle'] - math.atan2(self.start[1]-hit['pos'][1],self.start[0]-hit['pos'][0])
        context.window_manager.modal_handler_add(self)
        redraw(context)
        return {'RUNNING_MODAL'}

    def modal(self,context,event):
        if event.type in {'ESC','RIGHTMOUSE'} and event.value == 'PRESS':
            data.write(self.tree,self.original)
            redraw(context)
            return {'CANCELLED'}
        if event.type == 'MOUSEMOVE':
            p = point(context,event)
            delta = g.sub(p,self.start)
            ties = copy.deepcopy(self.original)
            angle = math.atan2(p[1]-self.hit['pos'][1],p[0]-self.hit['pos'][0])+self.offset
            if not event.alt:
                angle = round(angle/(math.pi/12))*(math.pi/12)
            for t in ties:
                if t['id'] in selection.of(self.tree):
                    if self.rotate:
                        t['angle'] += angle-self.hit['angle']
                    else:
                        t['pos'] = list(g.add(t['pos'],delta))
            data.write(self.tree,ties)
            redraw(context)
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


class NZT_OT_edit(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_edit'
    bl_label = 'Edit Selected Zip Ties'
    bl_options = {'REGISTER','UNDO'}
    action: EnumProperty(items=[('DELETE','Remove',''),('ROTATE','Rotate',''),('COLOR','Color',''),('PRUNE','Clean disconnected ties','')])
    angle: FloatProperty(default=math.pi/2)
    color: FloatVectorProperty(name='Tie color',subtype='COLOR',size=4,min=0,max=1,default=(.55,.55,.58,1))
    delete_nodes: BoolProperty(default=False,options={'HIDDEN'})

    def invoke(self,context,event):
        if self.action == 'COLOR':
            return context.window_manager.invoke_props_dialog(self)
        return self.execute(context)

    def execute(self,context):
        tree = rendering.tree_of(context)
        selected = selection.of(tree)
        if not selected and self.action != 'PRUNE':
            return {'PASS_THROUGH'}
        ties = data.read(tree)
        if self.action == 'DELETE':
            ties = [t for t in ties if t['id'] not in selected]
            selected.clear()
            if self.delete_nodes:
                # Restore logical connections and remove owned helpers before
                # deleting their endpoints, within the same undo step.
                data.write(tree,ties)
                for node in list(tree.nodes):
                    if node.select:
                        tree.nodes.remove(node)
                ties = data.prune(tree,ties)
        elif self.action == 'PRUNE':
            ties = data.prune(tree,ties)
        else:
            for t in ties:
                if t['id'] in selected:
                    if self.action == 'ROTATE':
                        t['angle'] += self.angle
                    else:
                        t['color'] = list(self.color)
        data.write(tree,ties)
        redraw(context)
        return {'FINISHED'}


class NZT_OT_box(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_box'
    bl_label = 'Box Select Ties and Nodes'
    bl_options = {'UNDO','BLOCKING'}

    def invoke(self,context,event):
        self.start = None
        self.extend = event.shift
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self,context,event):
        if event.type in {'ESC','RIGHTMOUSE'}:
            selection.boxes.pop(context.area.as_pointer(),None)
            redraw(context)
            return {'CANCELLED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            self.start = point(context,event)
        if self.start and event.type == 'MOUSEMOVE':
            p = point(context,event)
            selection.boxes[context.area.as_pointer()] = (self.start,p)
            redraw(context)
        if self.start and event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            tree = rendering.tree_of(context)
            p = point(context,event)
            lo = [min(self.start[k],p[k]) for k in (0,1)]
            hi = [max(self.start[k],p[k]) for k in (0,1)]
            inside = lambda v: all(lo[k]<=v[k]<=hi[k] for k in (0,1))
            chosen = selection.of(tree)
            if not self.extend:
                chosen.clear()
            chosen.update(t['id'] for t in data.read(tree) if inside(t['pos']))
            for n in tree.nodes:
                if not self.extend:
                    n.select = False
                if not routing.managed(n) and inside(n.location_absolute):
                    n.select = True
            redraw(context)
            selection.boxes.pop(context.area.as_pointer(),None)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


class NZT_OT_move_nodes(NodeOperator,bpy.types.Operator):
    bl_idname = 'node.zip_tie_move_selection'
    bl_label = 'Move Selected Nodes and Ties'
    bl_options = {'UNDO','BLOCKING'}

    def invoke(self,context,event):
        self.tree = rendering.tree_of(context)
        self.nodes = [(n,tuple(n.location)) for n in self.tree.nodes if n.select and not routing.managed(n)]
        self.ties = data.read(self.tree)
        self.start = point(context,event)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self,context,event):
        cancel = event.type in {'ESC','RIGHTMOUSE'} and event.value == 'PRESS'
        if cancel or event.type == 'MOUSEMOVE':
            d = (0,0) if cancel else g.sub(point(context,event),self.start)
            for n,pos in self.nodes:
                # Children of selected frames already inherit their parent's movement.
                parent = n.parent
                ancestors_selected = False
                while parent:
                    ancestors_selected |= parent.select
                    parent = parent.parent
                if not ancestors_selected:
                    n.location = g.add(pos,d)
            selected_nodes = {data.uid(n) for n,_ in self.nodes}
            ties = copy.deepcopy(self.ties)
            for t in ties:
                endpoints = {v for key in t['members'] for v in (json.loads(key)[0],json.loads(key)[2])}
                if t['id'] in selection.of(self.tree) or endpoints <= selected_nodes:
                    t['pos'] = list(g.add(t['pos'],d))
            data.write(self.tree,ties)
            redraw(context)
        if cancel:
            return {'CANCELLED'}
        if event.type in {'LEFTMOUSE','RET'} and event.value == 'PRESS':
            return {'FINISHED'}
        return {'RUNNING_MODAL'}


def add_keymaps():
    kc = bpy.context.window_manager.keyconfigs.addon
    if not kc:
        return
    km = kc.keymaps.new(name='Node Editor',space_type='NODE_EDITOR')
    # key_modifier preserves the bare Blender key command. Menu command also works without key.
    key = prefs(bpy.context).gesture_key
    entries = [('node.zip_tie_gesture','LEFTMOUSE','PRESS',dict(key_modifier=key)),
               ('node.zip_tie_pick','LEFTMOUSE','PRESS',dict(any=True)),
               ('node.zip_tie_pick','LEFTMOUSE','DOUBLE_CLICK',dict(any=True)),
               ('node.zip_tie_pick','RIGHTMOUSE','PRESS',dict(any=True))]
    for op,kind,value,kw in entries:
        item = km.keymap_items.new(op,kind,value,**kw)
        keymaps.append((km,item))
    keymaps.append((km,km.keymap_items.new('node.zip_tie_hover','MOUSEMOVE','ANY',any=True)))
    for key in ['DEL','BACK_SPACE']:
        item = km.keymap_items.new('node.zip_tie_edit',key,'PRESS')
        item.properties.action = 'DELETE'
        item.properties.delete_nodes = True
        keymaps.append((km,item))


def remove_keymaps():
    for km,item in keymaps:
        km.keymap_items.remove(item)
    keymaps.clear()


classes = [NZT_OT_hover,NZT_OT_gesture,NZT_OT_pick,NZT_OT_edit,NZT_OT_box,NZT_OT_move_nodes]
