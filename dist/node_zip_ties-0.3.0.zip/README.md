# Node Zip Ties 0.3.0

Works in unmodified Blender 5.2 using native reroute nodes. No patch or duplicate-noodle overlay is required. The add-on draws straps; Blender draws the wires.

Hold Z and drag across two or more wires, or choose Tie Wires from the node-editor Zip Ties context menu. Drag a tie; Shift-drag snaps rotation in 15-degree steps; Shift+Alt rotates freely. Ctrl-click toggles selection, Shift-click extends. Right-click for color, rotation and removal. Double-click or cut across a marker to remove it. The sidebar provides joint selection/movement, copy/paste, spacing and width settings.

Each tie adds three reroutes per strand. Removing the last tie restores the original direct connection. Native reroute handles can remain visible. Data and routing survive save/reload and continue to evaluate when the add-on is disabled. Earlier overlay-only ties are converted on load.

Use the provided Copy/Paste Nodes with Ties and Move Selected Nodes and Ties commands to keep straps and nodes together. Gesture picking uses approximate socket coordinates for complex custom layouts. Graphical gesture QA is pending; automated routing, evaluation, persistence, clipboard and undo tests pass in stock Blender 5.2.

Reference: https://github.com/safzanpirani/comfyui-zip-ties
See THIRD_PARTY_NOTICES.txt for the original MIT notice.

Select a strip and press **R** to rotate freely with the mouse. Left-click or Enter confirms; Esc or right-click restores the original rotation. R can also start while hovering a strip. Shift-drag snapping remains available.

Version 0.3 reorganizes the N sidebar: Tie Wires and selected-tie Color/Remove actions appear first; Appearance — All Ties, Nodes & Ties, and Maintenance are collapsed sections. Rotation buttons are removed only from this sidebar; R, Shift-drag and right-click rotation remain available. Appearance controls are global. Show Straps controls visibility only. The dedicated Color dialog starts from the selected tie color. Box Select intersects node bodies and straps. Copy/Paste and Move Together disable when unavailable.
