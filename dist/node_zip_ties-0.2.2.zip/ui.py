import math
import bpy
from . import rendering, sockets
from .preferences import prefs


def commands(layout):
    layout.operator('node.zip_tie_gesture',text='Tie Wires',icon='LINKED')
    layout.operator('node.zip_tie_rotate',text='Rotate Freely (R)')
    for angle,label in [(math.pi/4,'Rotate 45°'),(math.pi/2,'Rotate 90°')]:
        op = layout.operator('node.zip_tie_edit',text=label)
        op.action = 'ROTATE'
        op.angle = angle
    layout.operator('node.zip_tie_edit',text='Tie Color…').action = 'COLOR'
    layout.operator('node.zip_tie_edit',text='Remove Selected Ties',icon='X').action = 'DELETE'


class NZT_MT_context(bpy.types.Menu):
    bl_label = 'Zip Tie'

    def draw(self,context):
        commands(self.layout)


class NZT_PT_panel(bpy.types.Panel):
    bl_label = 'Node Zip Ties'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Zip Ties'

    def draw(self,context):
        layout = self.layout
        options = prefs(context)
        layout.label(text='Native reroute bundles',icon='LINKED')
        for field in ['enabled','spacing','width','color_mode']:
            layout.prop(options,field)
        commands(layout)
        layout.separator()
        layout.operator('node.zip_tie_box')
        layout.operator('node.zip_tie_move_selection')
        layout.operator('node.zip_tie_copy')
        layout.operator('node.zip_tie_paste')
        layout.operator('node.zip_tie_edit',text='Clean Disconnected Ties').action = 'PRUNE'
        if rendering.last_error:
            layout.label(text=rendering.last_error,icon='ERROR')


def context_menu(self,context):
    if rendering.tree_of(context):
        self.layout.separator()
        self.layout.menu('NZT_MT_context',text='Zip Ties')


classes = [NZT_MT_context,NZT_PT_panel]
