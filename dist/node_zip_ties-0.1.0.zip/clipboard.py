"""Explicit clipboard commands preserve ties in the same undo operation as nodes.

Uses Blender's clipboard for nodes. Tie metadata is session-local, and only applied
when pasted UUIDs match the corresponding copy. Ordinary Ctrl-C/V are untouched.
"""
import copy
import json
import uuid
import bpy
from . import data, rendering, selection

payload = None


class NZT_OT_copy(bpy.types.Operator):
    bl_idname = 'node.zip_tie_copy'
    bl_label = 'Copy Nodes with Ties'

    @classmethod
    def poll(cls,context):
        return rendering.tree_of(context) is not None

    def execute(self,context):
        global payload
        tree = rendering.tree_of(context)
        if not tree.is_editable:
            return {'CANCELLED'}
        data.repair_duplicate_ids(tree)
        chosen = {data.uid(n):tuple(n.location_absolute) for n in tree.nodes if n.select}
        ties = []
        for tie in data.read(tree):
            if all(json.loads(k)[0] in chosen and json.loads(k)[2] in chosen for k in tie['members']):
                ties.append(tie)
        result = bpy.ops.node.clipboard_copy()
        if result == {'FINISHED'}:
            payload = dict(nodes=chosen,ties=copy.deepcopy(ties))
        return result


class NZT_OT_paste(bpy.types.Operator):
    bl_idname = 'node.zip_tie_paste'
    bl_label = 'Paste Nodes with Ties'
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls,context):
        tree = rendering.tree_of(context)
        return tree is not None and tree.is_editable

    def execute(self,context):
        tree = rendering.tree_of(context)
        before = {n.as_pointer() for n in tree.nodes}
        result = bpy.ops.node.clipboard_paste()
        if result != {'FINISHED'}:
            return result
        pasted = [n for n in tree.nodes if n.as_pointer() not in before]
        mapping = {}
        offsets = []
        for n in pasted:
            old = data.uid(n)
            new = uuid.uuid4().hex
            n[data.NODE_ID] = new
            if payload and old in payload['nodes']:
                mapping[old] = new
                offsets.append(tuple(n.location_absolute[k]-payload['nodes'][old][k] for k in (0,1)))
        if not payload or not offsets:
            return result
        delta = offsets[0]
        if any(any(abs(o[k]-delta[k])>.01 for k in (0,1)) for o in offsets):
            return result
        ties = data.read(tree)
        live = {data.link_key(l) for l in tree.links}
        selected = selection.of(tree)
        selected.clear()
        for original in payload['ties']:
            tie = copy.deepcopy(original)
            keys = []
            for key in tie['members']:
                src,out,dst,inp = json.loads(key)
                if src not in mapping or dst not in mapping:
                    break
                keys.append(json.dumps([mapping[src],out,mapping[dst],inp],separators=(',',':')))
            if len(keys) == len(tie['members']) and set(keys) <= live:
                tie['members'] = keys
                tie['id'] = uuid.uuid4().hex
                tie['pos'] = [tie['pos'][k]+delta[k] for k in (0,1)]
                ties.append(tie)
                selected.add(tie['id'])
        data.write(tree,ties)
        return result


classes = [NZT_OT_copy,NZT_OT_paste]
