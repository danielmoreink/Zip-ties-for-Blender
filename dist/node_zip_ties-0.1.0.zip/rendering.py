import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from . import data, geometry as g, selection, sockets
from .preferences import prefs

handles = []
last_error = ''


def tree_of(context):
    space = context.space_data
    return space.edit_tree if space and space.type == 'NODE_EDITOR' else None


def usable(context):
    return prefs(context).enabled and (sockets.native_available() or prefs(context).preview_overlay)


def shown(tree, ties):
    live = {data.link_key(l) for l in tree.links if not l.is_hidden}
    return [t for t in ties if any(k in live for k in t['members'])]


def native_submit():
    """Runtime-only API: routes are consumed by the next native link draw."""
    context = bpy.context
    tree = tree_of(context)
    if not tree or not sockets.native_available():
        return
    options = prefs(context)
    ties = data.read(tree) if options.enabled else []
    scale = context.preferences.system.ui_scale
    for link in tree.links:
        link.clear_zip_tie_route()
        key = data.link_key(link)
        for tie in ties:
            if key in tie['members']:
                p, _ = g.lane(tie,key,options.spacing)
                link.add_zip_tie_point(p[0]*scale,p[1]*scale,tie['angle'],options.smoothness)


def line(points, color, width=2):
    if len(points) < 2:
        return
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
    shader.uniform_float('lineWidth', width)
    shader.uniform_float('color', color)
    batch_for_shader(shader,'LINE_STRIP',{'pos':points}).draw(shader)


def polygon(points,color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float('color', color)
    batch_for_shader(shader,'TRIS',{'pos':points},indices=[(0,1,2),(0,2,3)]).draw(shader)


def draw():
    global last_error
    context = bpy.context
    tree = tree_of(context)
    if not tree or not usable(context):
        return
    options = prefs(context)
    ties = shown(tree,data.read(tree))
    transform = lambda p: sockets.to_region(context,p)
    stroke = selection.preview.get(context.area.as_pointer())
    hits, cuts = (stroke[2],stroke[3]) if stroke else (set(),set())
    hover = selection.hovered.get(context.area.as_pointer())
    emphasized = set(hits)
    for tie in ties:
        if tie['id'] == hover or tie['id'] in selection.of(tree):
            emphasized.update(tie['members'])
    gpu.state.blend_set('ALPHA')
    try:
        # Native mode draws only temporary highlight overlays, using exact native endpoints.
        for link in tree.links:
            if link.is_hidden:
                continue
            key = data.link_key(link)
            if key not in emphasized and (sockets.native_available() or not any(key in t['members'] for t in ties)):
                continue
            curves = g.route(sockets.controls(link,context),ties,key,options.spacing,options.smoothness)
            color = (1,1,1,1) if key in emphasized else sockets.color(link,context)
            for curve in curves:
                line([transform(p) for p in g.sample(curve)],color)
        for tie in ties:
            active = tie['id'] in selection.of(tree) or tie['id'] == selection.hovered.get(context.area.as_pointer())
            border = (1,.1,.1,1) if tie['id'] in cuts else (1,1,1,1) if active else (.05,.05,.05,1)
            for poly in g.marker(tie,options.spacing,options.width):
                points = [transform(p) for p in poly]
                polygon(points,tie['color'])
                line(points+points[:1],border,2 if active else 1)
        if stroke:
            line([transform(stroke[0]),transform(stroke[1])],(1,.1,.1,1) if cuts else (1,1,1,1))
        box = selection.boxes.get(context.area.as_pointer())
        if box:
            a,b = box
            vertices = [a,(b[0],a[1]),b,(a[0],b[1]),a]
            line([transform(p) for p in vertices],(.65,.8,1,1),1)
        last_error = ''
    except Exception as exc:
        # Surface diagnostics once in UI, rather than flooding Blender's console every frame.
        last_error = f'{type(exc).__name__}: {exc}'
    finally:
        gpu.state.blend_set('NONE')


def register():
    handles.append(bpy.types.SpaceNodeEditor.draw_handler_add(native_submit,(), 'WINDOW','PRE_VIEW'))
    handles.append(bpy.types.SpaceNodeEditor.draw_handler_add(draw,(), 'WINDOW','POST_PIXEL'))


def unregister():
    if sockets.native_available():
        trees = list(bpy.data.node_groups)
        trees += [m.node_tree for m in bpy.data.materials if m.node_tree]
        trees += [s.node_tree for s in bpy.data.scenes if s.node_tree]
        trees += [w.node_tree for w in bpy.data.worlds if w.node_tree]
        for tree in trees:
            for link in tree.links:
                link.clear_zip_tie_route()
    for handle in handles:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handle,'WINDOW')
    handles.clear()
