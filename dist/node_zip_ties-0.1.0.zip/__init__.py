"""Node Zip Ties. See README for stock Blender versus native routing status."""
import bpy
from bpy.app.handlers import persistent
from . import preferences, interaction, rendering, selection, ui, clipboard

classes = [preferences.NZT_Preferences] + interaction.classes + clipboard.classes + ui.classes


@persistent
def reset_runtime(*_):
    selection.clear()
    clipboard.payload = None


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.NODE_MT_context_menu.append(ui.context_menu)
    interaction.add_keymaps()
    rendering.register()
    for handlers in [bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post]:
        handlers.append(reset_runtime)


def unregister():
    rendering.unregister()
    interaction.remove_keymaps()
    bpy.types.NODE_MT_context_menu.remove(ui.context_menu)
    for handlers in [bpy.app.handlers.load_post,bpy.app.handlers.undo_post,bpy.app.handlers.redo_post]:
        if reset_runtime in handlers:
            handlers.remove(reset_runtime)
    selection.clear()
    clipboard.payload = None
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
