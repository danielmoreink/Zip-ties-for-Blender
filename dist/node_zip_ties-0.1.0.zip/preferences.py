import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty


def prefs(context):
    entry = context.preferences.addons.get(__package__)
    return entry.preferences if entry else DEFAULTS


class Defaults:
    enabled = True
    preview_overlay = False
    spacing = 4.5
    width = 5.0
    smoothness = .25
    color_mode = 'RANDOM'
    gesture_key = 'Z'


DEFAULTS = Defaults()


def update_key(self, context):
    from . import interaction
    interaction.remove_keymaps()
    interaction.add_keymaps()


class NZT_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    enabled: BoolProperty(name='Display ties', default=True)
    preview_overlay: BoolProperty(name='Experimental overlay on stock Blender', default=False,
        description='Approximate sockets and duplicate noodles; does not satisfy routing parity')
    spacing: FloatProperty(name='Strand spacing', default=4.5, min=1, max=30)
    width: FloatProperty(name='Strap width', default=5, min=2, max=20)
    smoothness: FloatProperty(name='Curve control factor', default=.25, min=.05, max=.5)
    color_mode: EnumProperty(name='New tie color', items=[('RANDOM','Random',''),('GREY','Grey',''),('WIRES','Match wires','')])
    gesture_key: EnumProperty(name='Hold key', default='Z', update=update_key,
        items=[(k,k,'Hold then drag; bare key starts a modal gesture') for k in ['Z','X','C','T','Y']])

    def draw(self, context):
        layout = self.layout
        for name in ['enabled','gesture_key','color_mode','spacing','width','smoothness','preview_overlay']:
            layout.prop(self, name)
        layout.label(text='Stock Blender requires opt-in overlay; faithful routing requires native patch.', icon='INFO')
