"""Pure geometry; coordinates are node-editor units, angles counterclockwise.

Routing and lane ordering adapted from comfyui-zip-ties (MIT), Safzan Pirani.
"""
from math import cos, sin, hypot


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def mul(a, n):
    return (a[0] * n, a[1] * n)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1]


def axes(angle):
    return (cos(angle), sin(angle)), (-sin(angle), cos(angle))


def lane(tie, key, spacing):
    tangent, normal = axes(tie['angle'])
    offset = (tie['members'].index(key) - (len(tie['members']) - 1) / 2) * spacing
    return add(tie['pos'], mul(normal, offset)), tangent


def route(controls, ties, key, spacing=4.5, smoothness=.25):
    a, c0, c1, b = controls
    ordered = sorted((t for t in ties if key in t['members']),
                     key=lambda t: dot(sub(t['pos'], a), sub(b, a)))
    if not ordered:
        return [controls]
    points = [(a, (1, 0))] + [lane(t, key, spacing) for t in ordered] + [(b, (1, 0))]
    result = []
    for i, ((p, td), (q, ud)) in enumerate(zip(points, points[1:])):
        distance = hypot(*sub(q, p)) * smoothness
        result.append((p, c0 if i == 0 else add(p, mul(td, distance)),
                       c1 if i == len(points) - 2 else sub(q, mul(ud, distance)), q))
    return result


def sample(curve, count=48):
    a, b, c, d = curve
    result = []
    for i in range(count + 1):
        t = i / count
        u = 1 - t
        result.append(tuple(u**3*a[k] + 3*u*u*t*b[k] + 3*u*t*t*c[k] + t**3*d[k] for k in (0, 1)))
    return result


def intersection(p, q, r, s):
    u, v, w = sub(q, p), sub(s, r), sub(r, p)
    cross = lambda a, b: a[0]*b[1] - a[1]*b[0]
    den = cross(u, v)
    if abs(den) < 1e-10:
        return None
    t, j = cross(w, v)/den, cross(w, u)/den
    return t if 0 <= t <= 1 and 0 <= j <= 1 else None


def curve_hit(p, q, curves):
    hits = []
    for curve in curves:
        points = sample(curve)
        for a, b in zip(points, points[1:]):
            t = intersection(p, q, a, b)
            if t is not None:
                delta = sub(b, a)
                length = hypot(*delta) or 1
                hits.append((t, mul(delta, 1 / length)))
    return min(hits, key=lambda h: h[0]) if hits else None


def half_length(tie, spacing):
    return (len(tie['members']) - 1) * spacing / 2 + 3


def marker(tie, spacing=4.5, width=5):
    tangent, normal = axes(tie['angle'])
    h = half_length(tie, spacing)
    def transform(x, y):
        return add(tie['pos'], add(mul(tangent, x), mul(normal, y)))
    strap = [transform(x, y) for x, y in [(-width/2,-h),(width/2,-h),(width/2,h),(-width/2,h)]]
    head = [transform(x, y) for x, y in [(-4,-h-5),(4,-h-5),(4,-h+1),(-4,-h+1)]]
    return strap, head


def marker_hit(tie, p, spacing=4.5, width=5, pad=0):
    tangent, normal = axes(tie['angle'])
    d = sub(p, tie['pos'])
    x, y = dot(d, tangent), dot(d, normal)
    h = half_length(tie, spacing)
    return ((abs(x) <= width/2+pad and abs(y) <= h+pad) or
            (abs(x) <= 4+pad and -h-5-pad <= y <= -h+1+pad))


def marker_cut(tie, p, q, spacing=4.5, width=5):
    if marker_hit(tie, p, spacing, width) or marker_hit(tie, q, spacing, width):
        return True
    return any(intersection(p, q, a, b) is not None for poly in marker(tie, spacing, width)
               for a, b in zip(poly, poly[1:]+poly[:1]))
