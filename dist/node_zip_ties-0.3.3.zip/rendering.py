import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from . import data, geometry as g, selection, sockets
from .preferences import prefs

handles = []
last_error = ''


def tree_of(context):
    space = context.space_data
    return space.edit_tree if space and space.type == 'NODE_EDITOR' else None


def usable(context):
    return True  # Strap visibility does not disable creation or editing.


def shown(tree, ties):
    live = {data.link_key(l) for l in tree.links if not l.is_hidden}
    return [t for t in ties if any(k in live for k in t['members'])]


def line(points, color, width=2):
    if len(points) < 2:
        return
    shader = gpu.shader.from_builtin('POLYLINE_UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float('viewportSize', gpu.state.viewport_get()[2:])
    shader.uniform_float('lineWidth', width)
    shader.uniform_float('color', color)
    batch_for_shader(shader,'LINE_STRIP',{'pos':points}).draw(shader)


def polygon(points,color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    shader.bind()
    shader.uniform_float('color', color)
    batch_for_shader(shader,'TRIS',{'pos':points},indices=[(0,1,2),(0,2,3)]).draw(shader)


def draw():
    global last_error
    context = bpy.context
    tree = tree_of(context)
    if not tree or not prefs(context).enabled:
        return
    options = prefs(context)
    ties = shown(tree,data.read(tree))
    transform = lambda p: sockets.to_region(context,p)
    stroke = selection.preview.get(context.area.as_pointer())
    hits, cuts = (stroke[2],stroke[3]) if stroke else (set(),set())
    gpu.state.blend_set('ALPHA')
    try:
        for tie in ties:
            active = tie['id'] in selection.of(tree) or tie['id'] == selection.hovered.get(context.area.as_pointer())
            border = (1,.1,.1,1) if tie['id'] in cuts else (1,1,1,1) if active else (.05,.05,.05,1)
            for poly in g.marker(tie,options.spacing,options.width):
                points = [transform(p) for p in poly]
                polygon(points,tie['color'])
                line(points+points[:1],border,2 if active else 1)
        if stroke:
            line([transform(stroke[0]),transform(stroke[1])],(1,.1,.1,1) if cuts else (1,1,1,1))
        box = selection.boxes.get(context.area.as_pointer())
        if box:
            a,b = box
            vertices = [a,(b[0],a[1]),b,(a[0],b[1]),a]
            line([transform(p) for p in vertices],(.65,.8,1,1),1)
        last_error = ''
    except Exception as exc:
        # Surface diagnostics once in UI, rather than flooding Blender's console every frame.
        last_error = f'{type(exc).__name__}: {exc}'
    finally:
        gpu.state.blend_set('NONE')


def register():
    handles.append(bpy.types.SpaceNodeEditor.draw_handler_add(draw,(), 'WINDOW','POST_PIXEL'))


def unregister():
    for handle in handles:
        bpy.types.SpaceNodeEditor.draw_handler_remove(handle,'WINDOW')
    handles.clear()
